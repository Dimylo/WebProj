<?php
session_start();

$conn = pg_connect('host=localhost dbname=mydb port=5432 user=postgres password=12345');

$id = $_SESSION['id'];

 if (isset( $_POST['start1'],$_POST['last1'] )){
// $start= pg_escape_string($db,trim($_POST['start1']));
// $last=pg_escape_string($db,trim($_POST['last1']));
// $result = pg_query($conn, "SELECT latitudee7,longtitudee7 FROM usr_locations WHERE usr_id = '$id'");
$result = pg_query($conn, "SELECT latitudee7,longtitudee7 FROM usr_locations WHERE usr_id = '$id' AND timestamps>='".$_POST['start1']."' AND timestamps<='".$_POST['last1']."'");
// $result = pg_query($conn, "SELECT latitudee7,longtitudee7 FROM usr_locations WHERE usr_id = '$id' AND timestamps>='2019-12-10 11:28:56' AND timestamps<='2019-12-10 12:50:12'");
$data = array();

while($row = pg_fetch_assoc($result)){

  $data[] = $row;
}
echo json_encode($data);
}

 ?>
