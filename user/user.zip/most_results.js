google.charts.load("visualization", "1", { packages: ["corechart",'bar','line'] });

$(document).ready(function() {
  $('#search').click(function(e) {
    e.preventDefault();
    var st=$("#start").val();
    var la=$("#last").val();
    if(!st=='' && !la==''){
        $.ajax({
              type: "POST",
              url: 'date_s1.php',
              data: {'start1':st,'last1':la},
              success: function(response)
              {
                var data = JSON.parse(response);
                console.log(data);
                var MyArray=[];
                var DataArray=[];
                var html = "";
                var sum = 0;
                for (var i = 0; i < data.length; i++) {
                  var num = parseInt(data[i].num);
                  var type = data[i].act_type;
                  if (type == "STILL" || type == "TILTING" || type == "UNKNOWN" || type=="EXITING_VEHICLE") {
                    sum = sum;
                  }else{
                    sum = sum + num;
                  }
                }
                html += "<tr>";
                html += "<td>" +"ACTIVITY" +"</td>";
                html += "<td>" +"PERCENT(%)"+"</td>";
                for (let i = 0; i < data.length; i++) {
                  var num = parseInt(data[i].num);
                  var type = data[i].act_type;
                  if (type == "STILL" || type == "TILTING" || type == "UNKNOWN" || type == "EXITING_VEHICLE"){

                  }else {
                    num =num/sum*100;
                    html += "<tr>";
                    html += "<td>" +type  +"</td>";
                    html += "<td>" +Math.round(num) +"%"+"</td>";
                    html += "</tr>";
                    MyArray.push(type, num);
                  }
                }
                console.log(MyArray)

                document.getElementById("sum_activites").innerHTML = html;

                google.charts.setOnLoadCallback(DrawPieChart);

                function DrawPieChart() {
                    // DEFINE AN ARRAY OF DATA.
                    var arrSales = new google.visualization.DataTable();
                    arrSales.addColumn('string', 'Activity');
                    arrSales.addColumn('number', 'Times');

                    for (let i=0;i<MyArray.length-1;i+=2){
                      arrSales.addRows([
                        [MyArray[i],MyArray[i+1]]
                      ]);
                    }

                    // SET CHART OPTIONS.
                    var options = {
                        title: 'Activity Type',
                        is3D: true,
                        pieSliceText: 'value-and-percentage',
                        width:400,
                        height:300
                    };


                    // WHERE TO SHOW THE CHART (DIV ELEMENT).
                    var chart = new google.visualization.PieChart(document.getElementById('chart'));

                    // DRAW THE CHART.
                    chart.draw(arrSales, options);

                    var barchart_options = {title:'Barchart of Activities',
                                           width:400,
                                           height:300,
                                           legend: 'none'};
                    var barchart = new google.visualization.BarChart(document.getElementById('barchart_div'));
                    barchart.draw(arrSales, barchart_options);
                }

              }
        });
    }
});
//Ημέρα της εβδομάδας με τις περισσότερες εγγραφές ανά είδος δραστριότητας
  $('#search').click(function(e) {
    e.preventDefault();
    var st=$("#start").val();
    var la=$("#last").val();
    if(!st=='' && !la==''){
      $.ajax({
            type: "POST",
            url: 'firstday11.php',
            data: {'start1':st,'last1':la},
            success: function(response)
            {
              var data = JSON.parse(response);
              console.log(data)
              var day="";
              var type="";
              var html = "";
              html += "<tr>";
              html += "<td>" +"DAY "+"</td>";
              for (var i = 0; i < data.length; i++) {
                var day = data[i].topday;
                var type = data[i].activity;
                var quantity=data[i].num_of_activity;
                if (type == "STILL" || type == "TILTING" || type == "UNKNOWN"|| type== "EXITING_VEHICLE"){

                }else{
                  html += "<tr>";
                  html += "<td>" +day +"</td>";
                  html += "</tr>";
                }
                }
              document.getElementById("sum_day").innerHTML = html;
        }
      });
   }
  });
  $('#search').click(function(e) {
    e.preventDefault();
    var st=$("#start").val();
    var la=$("#last").val();
    if(!st=='' && !la==''){
      $.ajax({
            type: "POST",
            url: 'daychart.php',
            data: {'start1':st,'last1':la},
            success: function(response)
            {
              var data = JSON.parse(response);
              console.log(data)

                }

              //
              // google.charts.setOnLoadCallback(drawChart);
              // function drawChart() {
              //
              // var data = new google.visualization.DataTable();
              // data.addColumn('date', 'Time of Day');
              // data.addColumn('number', 'Number of Activities');
              //
              // for (let i=0;i<day.length-1;i+=2){
              //   data.addRows([
              //     [(new Date(day[i])), day[i+1]-1 ]
              //   ]);
              // }
              //
              // var options = {
              //   title: 'Sum of Activities',
              //   width: 900,
              //   height: 500,
              //   hAxis: {
              //     format: 'd/M/yy',
              //     gridlines: {count: 15}
              //   },
              //   vAxis: {
              //     gridlines: {color: 'none'},
              //     minValue: 0,
              //     maxValue: 1500
              //   }
              // };
              //
              // var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
              //
              // chart.draw(data, options);
          // }

      });
   }
  });
//'Ωρα της ημέρας με τις περισσότερες εγγραφές ανά είδος δραστριότητας
  $('#search').click(function(e) {
    e.preventDefault();
    var st=$("#start").val();
    var la=$("#last").val();
    if(!st=='' && !la==''){
    $.ajax({
          type: "POST",
          url: 'hour_date1.php',
          data: {'start1':st,'last1':la},
          success: function(response)
          {
            var hours=[];
            var data = JSON.parse(response);
            console.log(data)
            var html = "";
            html += "<tr>";
            html += "<td>" +"HOUR "+"</td>";
            for (var i = 0; i < data.length; i++) {

              let type=data[i].activity;
              let hour=data[i].tophour
              if (type == "STILL" || type == "TILTING" || type == "UNKNOWN" || type=="EXITING_VEHICLE"){
              }else {
                html += "<tr>";
                html += "<td>" +hour +"</td>";
                html += "</tr>";

              }
            }
            document.getElementById("sum_hour").innerHTML = html;
          }
      });
    }
  });

  $('#search').click(function(e) {
    e.preventDefault();
    var st=$("#start").val();
    var la=$("#last").val();
    if(!st=='' && !la==''){
    $.ajax({
          type: "POST",
          url: 'hourchart.php',
          data: {'start1':st,'last1':la},
          success: function(response)
          {
            var hours=[];
            var data = JSON.parse(response);
            console.log(data)


            var vehicleArray=[];
            var footArray=[];
            var bikeArray=[];
            for (let i = 0; i < data.length; i++) {
              let type=data[i].activity;
              var hour = parseInt(data[i].tophour);
              var quantity = parseInt(data[i].num_of_activity);
              if(type=='IN_VEHICLE'){
                vehicleArray.push(hour,quantity);
              }
              else if(type=='ON_FOOT'){
                  footArray.push(hour,quantity);
              }
              else if(type=='ON_BICYCLE'){
                  bikeArray.push(hour,quantity);
              }

            }
            console.log(vehicleArray)//,footArray,bikeArray)
            var max=[bikeArray.length,footArray.length,vehicleArray.length]
            var maximum=Math.max(...max);

            google.charts.setOnLoadCallback(drawChart);

          function drawChart() {

            var dataV = new google.visualization.DataTable();
            var dataB = new google.visualization.DataTable();
            var dataF = new google.visualization.DataTable();

            dataV.addColumn('number', 'Hour');
            dataV.addColumn('number', 'IN_VEHICLE');

            dataB.addColumn('number', 'Hour');
            dataB.addColumn('number', 'ON_BICYCLE');

            dataF.addColumn('number', 'Hour');
            dataF.addColumn('number', 'ON_FOOT');

            for (var i=0;i<vehicleArray.length-1;i+=2){
              dataV.addRows([
                [vehicleArray[i],vehicleArray[i+1]]
              ]);
            }

            for (let i=0;i<bikeArray.length-1;i+=2){
              dataB.addRows([
                [bikeArray[i],bikeArray[i+1]]
              ]);
            }

            for (let i=0;i<footArray.length-1;i+=2){
              dataF.addRows([
                [footArray[i],footArray[i+1]]
              ]);
            }

            var options = {
              chart: {
                title: 'Box Office Earnings in First Two Weeks of Opening',
                subtitle: 'in millions of dollars (USD)'
              },
              width: 400,
              height: 250
            };

            var chart = new google.charts.Line(document.getElementById('linechart_material_vehicle'));
            chart.draw(dataV, google.charts.Line.convertOptions(options));
            // var chartB = new google.charts.Line(document.getElementById('linechart_material_bike'));
            // chart.draw(dataB, google.charts.Line.convertOptions(options));
            var chartF = new google.charts.Line(document.getElementById('linechart_material_foot'));
            chartF.draw(dataF, google.charts.Line.convertOptions(options));
          }

        }
      });
    }
  });
});
