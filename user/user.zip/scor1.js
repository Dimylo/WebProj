
$(document).ready(function() {
        $.ajax({
              type: "POST",
              url: 'select_scor.php',
              success: function(response)
              {
                  var scor=JSON.parse(response);
                  console.log(scor);
                  var  html = 0;
                  var sum = 0;
                  var ecological=0;
                  var non_ecological = 0;
                  for (var i = 0; i < scor.length; i++) {
                    var type = scor[i].act_type;

                    if (type == "STILL" || type == "TILTING" || type == "UNKNOWN") {
                      sum = sum;
                    }else if (type == "ON_FOOT" || type == "ON_BICYCLE") {
                      ecological = ecological + 1;
                      sum = sum +1;
                    }else {
                      non_ecological = non_ecological +1;
                      sum = sum +1;
                    }

                  }
                  ecological = (ecological/sum)*100;
                  ecological =Math.round(ecological);
                  html +=ecological;
                  document.getElementById("scor").innerHTML = html;

          }
        });
        $.ajax({
              type: "POST",
              url: 'update_scor.php',
              success: function(response)
              {
                var update=JSON.parse(response);
                console.log(update)
                let board={};
                let j=0;
                for (let i = 0; i < update.length-1; i+=2) {
                  board[j]={name:update[i].username,scor:Math.round((update[i].rank/update[i+1].rank)*100)};
                  j+=1;
               }
               console.log(board)

               let sorted =Object.entries( board).sort((a, b) => b[1].scor - a[1].scor);

              console.log(sorted)

             }
        });
   });
