$(document).ready(function() {
        $.ajax({
              type: "POST",
              url: 'select_first_date1.php',
              success: function(response)
              {
                  var interval=JSON.parse(response);
                // console.log(interval);
                  var html = "";

                  html += "<td>" +"(" +interval[0].min +")-("+interval[0].max+")";
                  document.getElementById("eyros").innerHTML = html;
              }
        });
   });
